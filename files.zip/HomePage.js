import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Добро пожаловать в нашу клинику</h1>
      <p>Мы предлагаем широкий спектр медицинских услуг...</p>
    </div>
  );
};

export default HomePage;