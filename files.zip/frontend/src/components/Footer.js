import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>&copy; 2025 My Clinic. All rights reserved.</p>
    </footer>
  );
};

export default Footer;