import React from 'react';

const ServicesPage = () => {
  return (
    <div>
      <h1>Наши услуги</h1>
      <ul>
        <li>Услуга 1</li>
        <li>Услуга 2</li>
        <li>Услуга 3</li>
      </ul>
    </div>
  );
};

export default ServicesPage;